# -*- coding: utf-8 -*-


import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import *

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Health.Plus.Woman', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Health.Plus.Woman/resources/img', ''))

def CATEGORIES():
        addDir('זומבה','url',10,art + 'zomba1.png')
        addDir('פילאטיס','url',11,art + 'pilates1.png')
        addDir('אירובי','url',12,art + 'aerobic1.png')
        addDir('יוגה','url',13,art + 'yoga1.png')
        addDir('טיפוח נשים','url',14,art + 'makeup1.png')
        addDir('תזונה נכונה','url',15,art + 'nutrition1.png')
        addDir('רפואת נשים וילדים','url',16,art + 'health1.png')
        addDir('ספורט נשים','url',17,art + 'sports1.png')
        addDir('בידור ופנאי','url',18,art + 'bidor1.png')



def	zomba():
        addDir(''+translate(10012)+'','PLiRWC7Q54GioOmt7R89JpPsy9t0c9vLp8',1,art + 'zomba.png')
        addDir(''+translate(10013)+'','PLiRWC7Q54GioKGl8no2GUbVp3Qbbg2Utk',1,art + 'zomba.png')




def pilates():
        addDir(''+translate(40033)+'','PLiRWC7Q54Giob_DoXgZvAmjZyNjV3t7OR',1,art + 'pilates.png')


def aerobic():
        addDir(''+translate(30021)+'','PLiRWC7Q54Gio1RYbFvueHFyFdrmxUsY8X',1,art + 'aerobic.png')
        addDir(''+translate(30022)+'','PLiRWC7Q54Gir8caN-f8jL5K9W1FXBBRgd',1,art + 'aerobic.png')
        addDir(''+translate(30023)+'','PLiRWC7Q54GipUXwBhfIJy6pzJRetK5Nv2',1,art + 'aerobic.png')
        addDir(''+translate(30024)+'','PLiRWC7Q54GirImmtEfQkLgYgcl3_aHm55',1,art + 'aerobic.png')
        addDir(''+translate(30025)+'','PLOZ5nscrPV88ehnfWI7UmuQ_fwtIu3a68',1,art + 'aerobic.png')
        addDir(''+translate(30026)+'','PLMHMyl3oeyh0ryXE6ypetk9c89oe5HL5u',1,art + 'aerobic.png')
        addDir(''+translate(30027)+'','PL1c41tQdiDhPTthizOvwpHsV4kaRVEatr',1,art + 'aerobic.png')
        addDir(''+translate(30028)+'','PLiRWC7Q54GipOza_m-7MN8EG1SaYTDDKf',1,art + 'aerobic.png')
        addDir(''+translate(30029)+'','PL1c41tQdiDhPsKxBxXIWIUDxb6thKBK8R',1,art + 'aerobic.png')
        addDir(''+translate(30030)+'','PLiRWC7Q54GipT9LzDiyiUcgliv-KrGRae',1,art + 'aerobic.png')
        addDir(''+translate(30031)+'','PLsPcs4lOzaD1bpN_Wc5buSbSJBJpQbeGc',1,art + 'aerobic.png')
        addDir(''+translate(30032)+'','PLsPcs4lOzaD0P3zZ3egOpIpnx8cmqq3r_',1,art + 'aerobic.png')
        addDir(''+translate(30033)+'','PLsPcs4lOzaD0rZGrbcNTnrsiM4NA1gbca',1,art + 'aerobic.png')
        addDir(''+translate(30034)+'','PLsPcs4lOzaD0luf_PeFBCB6uwILXybLBc',1,art + 'aerobic.png')
        addDir(''+translate(30035)+'','PLsPcs4lOzaD1kNZBl8yvMJxShiufQsl8i',1,art + 'aerobic.png')
        addDir(''+translate(30036)+'','PLsPcs4lOzaD2pg6TWXr0ZcMGjw7Qgx40q',1,art + 'aerobic.png')
        addDir(''+translate(30037)+'','PLsPcs4lOzaD2YznNU0Baz7tFXBUK6cB8F',1,art + 'aerobic.png')
        addDir(''+translate(30038)+'','PLsPcs4lOzaD0donVsJC_598bIRuTa-MZL',1,art + 'aerobic.png')
        addDir(''+translate(30039)+'','PLsPcs4lOzaD3Hze49tFRIC-EKQHDS22DS&index=42',1,art + 'aerobic.png')
        addDir(''+translate(30040)+'','PLsPcs4lOzaD0_FHbeaUgw4pVPur9plbtq',1,art + 'aerobic.png')
        addDir(''+translate(30041)+'','PLsPcs4lOzaD1CzRDnvlQAeQRU67RiFsS9',1,art + 'aerobic.png')
        addDir(''+translate(30042)+'','PLsPcs4lOzaD1BcSl6qtGazgq0PGpsn0TY',1,art + 'aerobic.png')
        addDir(''+translate(30043)+'','PLsPcs4lOzaD37I2dyaIPwmhbjjQ_km55P',1,art + 'aerobic.png')
        addDir(''+translate(30044)+'','PLsPcs4lOzaD0iz7ESUq0LVePdydugJzHy',1,art + 'aerobic.png')
        addDir(''+translate(30045)+'','PLsPcs4lOzaD0E3nSjvufQo1PF4iUk_VXS',1,art + 'aerobic.png')
        addDir(''+translate(30046)+'','PLsPcs4lOzaD19MaOusgNDSBY79K0DDZuu',1,art + 'aerobic.png')
        addDir(''+translate(30047)+'','PLsPcs4lOzaD1KFb5sG9cXxgFlsicP8cWA',1,art + 'aerobic.png')
        addDir(''+translate(30048)+'','PLsPcs4lOzaD3LSSZtz6UnPkGOD7rnxkqI',1,art + 'aerobic.png')
        addDir(''+translate(30049)+'','PLsPcs4lOzaD078QrnTh7tMQ_vBj26ZI3I',1,art + 'aerobic.png')
        addDir(''+translate(30050)+'','PL9kERLsITKLoWpL-FOdMqTLQjhaeHKPHd',1,art + 'aerobic.png')
        addDir(''+translate(30051)+'','PL9kERLsITKLr_ZNw01ONH2H8GkUqoQsc9',1,art + 'aerobic.png')
        addDir(''+translate(30052)+'','PL254A5A4C3C292D34',1,art + 'aerobic.png')
        addDir(''+translate(30053)+'','PL9kERLsITKLrBrU-0repW-vA5surKwTO6',1,art + 'aerobic.png')

		
def yoga():
        addDir(''+translate(50001)+'','PLui6Eyny-Uzx2jQYA8MS73ND2kUMHyII8',1,art + 'yoga.png')
        addDir(''+translate(50002)+'','PLui6Eyny-UzxL6NjFMYD5-vESNii8_aLi',1,art + 'yoga.png')
        addDir(''+translate(50003)+'','PLui6Eyny-UzzoiewtypZsiw2OIUz2btnD',1,art + 'yoga.png')
        addDir(''+translate(50004)+'','PLui6Eyny-UzzyYOtKfMfLl0h94mjsUKv9',1,art + 'yoga.png')
        addDir(''+translate(50005)+'','PLui6Eyny-Uzx5BRNB2_Kvycrn5h9OsaHC',1,art + 'yoga.png')
        addDir(''+translate(50006)+'','PLui6Eyny-UzzVLhyWdH7UAMd4dOQFCAhP',1,art + 'yoga.png')
        addDir(''+translate(50007)+'','PLui6Eyny-UzzWwB4h9y7jAzLbeuCUczAl',1,art + 'yoga.png')
        addDir(''+translate(50008)+'','PLui6Eyny-Uzw1DKEgFQZ5m38iZAXF1Xk5',1,art + 'yoga.png')
        addDir(''+translate(50009)+'','PLui6Eyny-Uzwzd-9fi_cmhz3UW9gS1raf',1,art + 'yoga.png')
        addDir(''+translate(50010)+'','PLui6Eyny-UzwheLDyEScgdgbh7z3FgNCX',1,art + 'yoga.png')
        addDir(''+translate(50011)+'','PLui6Eyny-UzwmsJ9vILet4TJwqcINCz4j',1,art + 'yoga.png')
        addDir(''+translate(50012)+'','PLui6Eyny-UzxMFVoPmxcPX1MOeLyV5uKQ',1,art + 'yoga.png')
        addDir(''+translate(50013)+'','PLui6Eyny-UzyugJTu3l1YFL0k3nGIlaz9',1,art + 'yoga.png')
        addDir(''+translate(50014)+'','PLui6Eyny-UzwCnJ3-L2ATvLNHE3zsunZi',1,art + 'yoga.png')
        addDir(''+translate(50015)+'','PLui6Eyny-UzxIFYEeJgFNaSJTGZLuwHUY',1,art + 'yoga.png')
        addDir(''+translate(50016)+'','PLui6Eyny-UzwxbWCWDbTzEwsZnnROBTIL',1,art + 'yoga.png')
        addDir(''+translate(50017)+'','PLiRWC7Q54GiqQ5YTQkyqT4IoyVY83qn-h',1,art + 'yoga.png')
        addDir(''+translate(50018)+'','PLiRWC7Q54GiotNNwM2EHiMTqv-Kc838On',1,art + 'yoga.png')




def makeup():
        addDir(''+translate(60001)+'','PLFXDHq8EOmDn2pbbDjKxmozigY_xSznd7',1,art + 'makeup.png')
        addDir(''+translate(60002)+'','PLFXDHq8EOmDk96Zi8ibHerZ7pkQD3_bsr',1,art + 'makeup.png')
        addDir(''+translate(60003)+'','PLFXDHq8EOmDlro7O-7ehHR1zvBGybh1gq',1,art + 'makeup.png')
        addDir(''+translate(60004)+'','PLFXDHq8EOmDmHeuxiQskYVRnmvQmBsYhi',1,art + 'makeup.png')
        addDir(''+translate(60005)+'','PLFXDHq8EOmDncTAQrC9W990a0dBtUFVyH',1,art + 'makeup.png')
        addDir(''+translate(60006)+'','PLFXDHq8EOmDkL26eSMDUXFdr3_zZ1HrPM',1,art + 'makeup.png')
        addDir(''+translate(60007)+'','PLFXDHq8EOmDnupay8fnrOSKvXXnbB-SOW',1,art + 'makeup.png')
        addDir(''+translate(60008)+'','PLFXDHq8EOmDntDSxLwcjxmJgwZH61pE26',1,art + 'makeup.png')
        addDir(''+translate(60009)+'','PLFXDHq8EOmDnDeKTJ_pSx38KgMgISFJe_',1,art + 'makeup.png')
        addDir(''+translate(60010)+'','PLFXDHq8EOmDkP2UQ5QDu8DdWZELEt_SkQ',1,art + 'makeup.png')
        addDir(''+translate(60011)+'','PLFXDHq8EOmDl98smEUzA8FT9Vq4QSk9zQ',1,art + 'makeup.png')
        addDir(''+translate(60012)+'','PLFXDHq8EOmDla8l08ACyq9HHUbspDUW4f',1,art + 'makeup.png')
        addDir(''+translate(60013)+'','PLqrO4mc6RUZ1_qzjLQXdwDAZ64G2FC9G6',1,art + 'makeup.png')
        addDir(''+translate(60014)+'','PLqrO4mc6RUZ0235ria9ERbja6KYJjfFsI',1,art + 'makeup.png')
        addDir(''+translate(60015)+'','PLqrO4mc6RUZ2tz5hzygNN_V534AueUrr9',1,art + 'makeup.png')
        addDir(''+translate(60016)+'','PLqrO4mc6RUZ16Fo-07RdO1tWI52QV0EPU',1,art + 'makeup.png')
        addDir(''+translate(60017)+'','PLqrO4mc6RUZ2yOt-tN_39_RLx2-jTNvrk',1,art + 'makeup.png')
        addDir(''+translate(60018)+'','PLqrO4mc6RUZ3dIAlWlmEuGbhmRDZMkTfF',1,art + 'makeup.png')
        addDir(''+translate(60019)+'','PLqrO4mc6RUZ09_liYs7AF1SkTWifaYvAI',1,art + 'makeup.png')
        addDir(''+translate(60020)+'','PgrO5FA&list=PLqrO4mc6RUZ1zfMeIMiNV04l-aLSEpZj8',1,art + 'makeup.png')
        addDir(''+translate(60021)+'','PLqrO4mc6RUZ36DDv8xQVtEvh5vZys6eYV',1,art + 'makeup.png')
        addDir(''+translate(60022)+'','PLqrO4mc6RUZ2wfo7JsLyUcsHN4iAA4FrL',1,art + 'makeup.png')
        addDir(''+translate(60023)+'','PLqrO4mc6RUZ31heO5EEuPhJnukmCXrbhz',1,art + 'makeup.png')
        addDir(''+translate(60024)+'','PLzVhGARzals0Mq60Vh45rHJ-O5CO77aZv',1,art + 'makeup.png')
        addDir(''+translate(60025)+'','PLzVhGARzals1SsNYtgViwCaVkis6blrPA',1,art + 'makeup.png')
        addDir(''+translate(60026)+'','PLzVhGARzals3nwticn-2TdWye7NkXXPyX',1,art + 'makeup.png')
        addDir(''+translate(60027)+'','PLzVhGARzals1TmxNY8UqVj3Hflpl_jqtH',1,art + 'makeup.png')
        addDir(''+translate(60028)+'','PLzVhGARzals0QMJFzdKG2h23bZqGytzJ1&index=4',1,art + 'makeup.png')
        addDir(''+translate(60029)+'','PLzVhGARzals1BfbV-QmAcxi4sBwN1B5gI',1,art + 'makeup.png')
        addDir(''+translate(60030)+'','PLiRWC7Q54GioXKgbaifrEfR-MFOMgibc2',1,art + 'makeup.png')
        addDir(''+translate(60031)+'','PLiRWC7Q54GioxI08Rv1TfklGBElDQAN43',1,art + 'makeup.png')



def nutrition():
        addDir(''+translate(70001)+'','PLOZ5nscrPV8-A-8jwKUa5o5gCoOEyLhIn',1,art + 'nutrition.png')
        addDir(''+translate(70002)+'','PLiRWC7Q54Gioo6w9A2nNdL-mrGUh78V-n',1,art + 'nutrition.png')
        addDir(''+translate(70003)+'','PLiRWC7Q54Giq6Dz1S0SV2JwP2jjCI1rGZ',1,art + 'nutrition.png')
        addDir(''+translate(70004)+'','PLiRWC7Q54GipTRJBIkECddRvS2rlJ8Pm7',1,art + 'nutrition.png')
        addDir(''+translate(70005)+'','PLRASpuvjMTWacQDUkuj8fEps665OyWwRB',1,art + 'nutrition.png')
        addDir(''+translate(70006)+'','PLiRWC7Q54Gio9WFuWPNfimkR3PAzUUKEp',1,art + 'nutrition.png')


def health():
        addDir(''+translate(80001)+'','PLOZ5nscrPV89p2nUMt0NhA3x7_r2PSR8Z',1,art + 'health.png')
        addDir(''+translate(80002)+'','PLiRWC7Q54GiqCc46RphIDB-z2v2gvcSjI',1,art + 'health.png')
        addDir(''+translate(80003)+'','PLFXDHq8EOmDmBoNj0sL8fxBhvTwcXbh8q',1,art + 'health.png')
        addDir(''+translate(80004)+'','PLOZ5nscrPV8_RBfntU95GGO06xZP7oPTX',1,art + 'health.png')
        addDir(''+translate(80005)+'','PLOZ5nscrPV8_QjeLeLPoWDiwIthS-wCio',1,art + 'health.png')
        addDir(''+translate(80006)+'','PLOZ5nscrPV884L8qUfArGFJLUOBw7DZdn',1,art + 'health.png')
        addDir(''+translate(80007)+'','PLOZ5nscrPV8-ERQ71bqMoZDGC_j5RRUvD',1,art + 'health.png')
        addDir(''+translate(80008)+'','PLOZ5nscrPV882yCk_t1reNvyNaFR-HTgG',1,art + 'health.png')
        addDir(''+translate(80009)+'','PLOZ5nscrPV89hpnIvmnS5KkHril_xgjv6',1,art + 'health.png')
        addDir(''+translate(80010)+'','PLOZ5nscrPV88Sc4KmJ5r1bm-2LucyzGPb',1,art + 'health.png')
        addDir(''+translate(80011)+'','PLOZ5nscrPV8_LUZgY4LeYHH3BX3vz1Bsw',1,art + 'health.png')
        addDir(''+translate(80012)+'','PLiRWC7Q54GipLl8pJriQw_G5pTY4yCwaX',1,art + 'health.png')
        addDir(''+translate(80013)+'','PLiRWC7Q54GipPDl1tX2m9K6vy2mxUIJ1O',1,art + 'health.png')
        addDir(''+translate(80014)+'','PLiRWC7Q54GioJgKYb-INFeeAVRzUQWheC',1,art + 'health.png')
        addDir(''+translate(80015)+'','PLiRWC7Q54Gir72RvSiYQRpp_UsJA_K7uu',1,art + 'health.png')
        addDir(''+translate(80016)+'','PLiRWC7Q54Gir-8ToAGOlr7kEjxnEzJXck',1,art + 'health.png')
        addDir(''+translate(80017)+'','PLN7ydbvoUTMU41t1mRrkpEkXvXnK5a3ie&index=4',1,art + 'health.png')
        addDir(''+translate(80018)+'','PLtJVSAZ-prxoe7rT17G6KHTWeZKxUtUpA&index=3',1,art + 'health.png')
        addDir(''+translate(80019)+'','PLRASpuvjMTWafSsLquQKZxptsqKUCBxuM',1,art + 'health.png')
        addDir(''+translate(80020)+'','PLiRWC7Q54GioRMDeVmPmSE9E2VcCd1KFF',1,art + 'health.png')
        addDir(''+translate(80021)+'','PLRASpuvjMTWb8wkRYVoDJaP87PPgOzOvX',1,art + 'health.png')
        addDir(''+translate(80022)+'','PLRASpuvjMTWalheVtnAjthpSd5gCKfjav',1,art + 'health.png')
        addDir(''+translate(80023)+'','PLWQK8fFETRkuTqKv2Rm6bV4IU41a01psW',1,art + 'health.png')




def sports():
        addDir(''+translate(90001)+'','PLMHMyl3oeyh3BqeGm4CTfixEQ1oGKGe4A',1,art + 'sports.png')
        addDir(''+translate(90002)+'','PLMHMyl3oeyh00NqGBY-Y4WxPRInh9s5ul',1,art + 'sports.png')
        addDir(''+translate(90003)+'','PLMHMyl3oeyh2TOD62h5_ljtiyqwE9i2pU',1,art + 'sports.png')
        addDir(''+translate(90004)+'','PLMHMyl3oeyh2X2Cf3kQ7RWJX2sb3CWZ_-',1,art + 'sports.png')
        addDir(''+translate(90005)+'','PLMHMyl3oeyh1zWX_45mwhUyY31o2yYwd2',1,art + 'sports.png')
        addDir(''+translate(90006)+'','PLMHMyl3oeyh1FhDZinVD5FiLV1PxE4n9t',1,art + 'sports.png')
        addDir(''+translate(90007)+'','PLMHMyl3oeyh3vrW3qRRq-onxG1XAIru6n',1,art + 'sports.png')
        addDir(''+translate(90008)+'','PLiRWC7Q54GipVZHs1YGurwFNK-gktSd3T',1,art + 'sports.png')


def bidor():
        addDir(''+translate(11001)+'','PL9Pg1--nVI-CoPB9IdwmSkRufOgpuCl7z',1,art + 'bidor.png')
        addDir(''+translate(11002)+'','PL9Pg1--nVI-Dec23P2ZkgwLxKJNfLtRHT',1,art + 'bidor.png')
        addDir(''+translate(11003)+'','PL9Pg1--nVI-DPm0PZafI_RrVUbs00KR4V&index=8',1,art + 'bidor.png')
        addDir(''+translate(11004)+'','PL9Pg1--nVI-BzGNV3cOUQfuGH0HGFPA3c',1,art + 'bidor.png')
        addDir(''+translate(11005)+'','PL9Pg1--nVI-A_YA5q6FJRJCU-2eun-XvL',1,art + 'bidor.png')
        addDir(''+translate(11006)+'','PL9Pg1--nVI-A-ZyCv5VWIf1w18Z9o7lnB',1,art + 'bidor.png')
        addDir(''+translate(11007)+'','PL9Pg1--nVI-CmL20prVKQypHq80yD8O5c',1,art + 'bidor.png')
        addDir(''+translate(11008)+'','PLiRWC7Q54GiqaoOxINXZftJyCxA0vlcfn',1,art + 'bidor.png')
        addDir(''+translate(11009)+'','PLiRWC7Q54GipjR1MsxSaS5jvCoRam7K2i',1,art + 'bidor.png')



def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try:
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="NEXT.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
			

def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()

elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5:
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)

elif mode==10:
        print ""+url
        zomba()

elif mode==11:
        print ""+url
        pilates()

elif mode==12:
        print ""+url
        aerobic()

elif mode==13:
        print ""+url
        yoga()

elif mode==14:
        print ""+url
        makeup()

elif mode==15:
        print ""+url
        nutrition()

elif mode==16:
        print ""+url
        health()

elif mode==17:
        print ""+url
        sports()

elif mode==18:
        print ""+url
        bidor()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
