# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates, Guides & Merlin Tube
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from YouTube & Merlin Tube addons
#
# Thanks To: Merlin
# Author:    Merlin
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.merlinmusic'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

xbmc.executebuiltin('Container.SetViewMode(500)')

# Artists Added Initially
YOUTUBE_CHANNEL_ID_1 = "PLPTQhPSe_1v6RD4j2hX-4BxPMvrghYKKP"			#Avicii
YOUTUBE_CHANNEL_ID_2 = "PL87C8BE517EDE6008"							#Shania Twain
YOUTUBE_CHANNEL_ID_3 = "PLqeOvB-u67NAYU6i6EgcninTN53WilKkX"			#Aerosmith
YOUTUBE_CHANNEL_ID_4 = "PLAEq5ujOZ71psbJ1v4N4w8jmCBKHdrC2U"			#Katy Perry
YOUTUBE_CHANNEL_ID_5 = "PL6547C3CF6106002E"							#Bryan Adams
YOUTUBE_CHANNEL_ID_6 = "PLy5C65bvjyurvHyQdB8KtjB2M_HQixXlA"			#One Direction
YOUTUBE_CHANNEL_ID_7 = "PLzH7DPYb-ewdHbItI07YZp1_T9YsXsvsb"			#Journey
YOUTUBE_CHANNEL_ID_8 = "PLNaDy1xRJz8Vh5VHEuO7R68w7f7JVYtgB"			#Taylor Swift
YOUTUBE_CHANNEL_ID_9 = "PLuqyTcRjDR7xynm3h7vu6TZeXSxJ4tkmG"			#Meghan Trainor
YOUTUBE_CHANNEL_ID_10 = "PLGz7zkw1o5OrVF-9-Xb0GzjDpBHnQX2Ed"		#Lady Gaga
YOUTUBE_CHANNEL_ID_11 = "PLi7ihgkEws7Tc-nS8VRpFvJPMmwx8KNbF"		#Adele
YOUTUBE_CHANNEL_ID_12 = "PLjcLSiteN_7BLSqL-lg5p4RAAHQ65mG0q"		#Ariana Grande
YOUTUBE_CHANNEL_ID_13 = "PLIXR_3Q6owLZlOOIWrHRLgNd9y4KFYjlr"		#Maroon 5
YOUTUBE_CHANNEL_ID_14 = "PL1MMYn9UvtEAyEWM6_-CHrIPnTzMx1FK4"		#U2
YOUTUBE_CHANNEL_ID_15 = "PLFD7A55BEFAD8CCCA"						#Take That
YOUTUBE_CHANNEL_ID_16 = "PLuvyXsl3VC6SIZbntZYPvURcll7whk3Fo"		#Demi Lovato
YOUTUBE_CHANNEL_ID_17 = "PL3kTUMlpIWsfoWceYbRUDhvuZGSSNKSec"		#Beyonce
YOUTUBE_CHANNEL_ID_18 = "PL4324C6BD2E9BA7F8"						#Shakira
YOUTUBE_CHANNEL_ID_19 = "PL191892FAB782CF17"						#Britney Spears
YOUTUBE_CHANNEL_ID_20 = "PLSKiP8AuSHijcEVRtse7ucC2Q2JLb5fA2"		#ACDC
YOUTUBE_CHANNEL_ID_21 = "PLEF64F4FC4E092A44"						#Ricky Martin
YOUTUBE_CHANNEL_ID_22 = "PLReI40KGodv4AQ6_v7gO92ezfX81kFSYy"		#ColdPlay
YOUTUBE_CHANNEL_ID_23 = "PLmo4pBukfRoN8SB5RKvfiY9CTl9pI_IFc"		#The Beatles
YOUTUBE_CHANNEL_ID_24 = "PL88B0CBA209D81A95"						#Bon Jovi
YOUTUBE_CHANNEL_ID_25 = "PLOOBElWP-gj6hl7PQVcZak9FGri0ppeWG"		#Madonna
YOUTUBE_CHANNEL_ID_26 = "PL8cFaF2b783Ls-_n2LcW25VzdHXJphxSx"		#Prince
YOUTUBE_CHANNEL_ID_27 = "PLqDzNilwDj_dm_BOGxoCRmvA6CheRwAiw"		#Queen
YOUTUBE_CHANNEL_ID_28 = "PLdq8YZzQBHEs9ahG1TjPrxdIFrWUoKVKW"		#Kelly Clarkson
YOUTUBE_CHANNEL_ID_29 = "PLuUrokoVSxleUazGSbv2vp6CyzIGpMJVd"		#Drake
YOUTUBE_CHANNEL_ID_30 = "PLSDQwibGBpnqLQFjnlG9y8zeGzcn1aooe"		#Meatloaf
YOUTUBE_CHANNEL_ID_31 = "PLJ8y7DDcrI_p8LixOD4nVgrr9P6f4n2Lv"		#David Bowie
YOUTUBE_CHANNEL_ID_32 = "PLVw7QlYJFb4c6lxTOrZorHDxc51Yd1lQ6"		#Fall Out Boy
YOUTUBE_CHANNEL_ID_33 = "PL4AA6BF35EC374F87"						#Mary J Blige
YOUTUBE_CHANNEL_ID_34 = "PLC0w3lEHx2SGnJBfh5f2tSDBQI0iRjfdu"		#Eminem
YOUTUBE_CHANNEL_ID_35 = "PLD7B470256637D6BC"						#Blur
YOUTUBE_CHANNEL_ID_36 = "PLF3FE9FEB122AE2A4"						#Nirvana
YOUTUBE_CHANNEL_ID_37 = "PL5PPctPwu7YUwz_5nfSycCMm6SytRSfB4"		#Red Hot Chilli Peppers
YOUTUBE_CHANNEL_ID_38 = "PL6C30A3480A63AC0A"						#My Chemical Romance
YOUTUBE_CHANNEL_ID_39 = "PL4AA9A20B17A0FED8"						#Guns N Roses
YOUTUBE_CHANNEL_ID_40 = "PLFFC0DE5C257B32AF"						#Rolling Stones
YOUTUBE_CHANNEL_ID_41 = "PLh7uAKJv9QJVg3zs0c9y_W6Dc6qlETHUN"		#Big Country
YOUTUBE_CHANNEL_ID_42 = "PL5EB34E37DCF18712"						#Blink 182
YOUTUBE_CHANNEL_ID_43 = "PL597E0BDDC1D74ED2"						#Foo Fighters
YOUTUBE_CHANNEL_ID_44 = "PLo6aG-353CqkrrzXl8NWN6bEDdKjfH4gi"		#Green Day
YOUTUBE_CHANNEL_ID_45 = "PLXYWN2_ZvdRZ4VmlVM-L4_kojm22NfD4j"		#Johnny Cash
YOUTUBE_CHANNEL_ID_46 = "PLKGG5CxpTifyt4svF_0BuHzhJPndsJCD1"		#Elvis Presley
YOUTUBE_CHANNEL_ID_47 = "PLF58A67AE7A1B237F"						#Buddy Holly
YOUTUBE_CHANNEL_ID_48 = "PLcBnXOGVdm9B2sgRdGUcSyjood5UKEIht"		#Tracy Chapman
YOUTUBE_CHANNEL_ID_49 = "PL777D73434EF80630"						#Paul Weller
YOUTUBE_CHANNEL_ID_50 = "PLjavp-nstZziWawxOxFDo6PLJfijnkrGh"		#Stereophonics
YOUTUBE_CHANNEL_ID_51 = "PLDhVYwv-_6NM4oL5iMNnMBA63kHUiFncv"		#UB40
YOUTUBE_CHANNEL_ID_52 = "PL260937C51C5B5FB5"						#Evanescence
YOUTUBE_CHANNEL_ID_53 = "PLu4DnfQbWb3P2kmIUYVyUeva9i51vhCDd"		#Creed
YOUTUBE_CHANNEL_ID_54 = "PLr-J5bYC60jTq1MaVl0g87XaHvWhDFmvF"		#Cliff Richard
YOUTUBE_CHANNEL_ID_55 = "PLBiPNxqFKPZI948_8dohmZxxjvJxYIXSx"		#Linkin Park
YOUTUBE_CHANNEL_ID_56 = "PLA70BDEC842EFD1B1"						#Westlife
YOUTUBE_CHANNEL_ID_57 = "PLj00fYFXgI0QLxOzOSA_MY1EO0NAutBQo"		#Rod Stewart
YOUTUBE_CHANNEL_ID_58 = "PLluhO3FgxrHuqHKKWtn_M5pxNQiOEVlb5"		#Sam Smith
YOUTUBE_CHANNEL_ID_59 = "PLWoovEpjozlfbVaY6-xRUv1w1JC8-BmuR"		#John Legend
YOUTUBE_CHANNEL_ID_60 = "PLv-Exq9d7jl7lg-A7WFmcKt-s79AwkZ9h"		#The Script
 # Artists Added 18/05
YOUTUBE_CHANNEL_ID_61 = "PLA910D381CD5AF74E"						#Elton John
YOUTUBE_CHANNEL_ID_62 = "PLB-99rPb6xnq69HLE00sZUj3Sf5L8Sbz_"		#ELO
YOUTUBE_CHANNEL_ID_63 = "PLBB4F6C1BDF5A66E2"						#Simply Red
YOUTUBE_CHANNEL_ID_64 = "PLEsEn8S6SO1smXGO1vFz89ViVfegBRyyE"		#Ultravox
YOUTUBE_CHANNEL_ID_65 = "PLC2778034B7ABC755"						#Rita Ora
YOUTUBE_CHANNEL_ID_66 = "PL47722DF8584CEEDB"						#Michael Buble
YOUTUBE_CHANNEL_ID_67 = "PLDG6yIB7duTHm99XZAGbcaJu0u-fRmJJD"		#Michael Ball
YOUTUBE_CHANNEL_ID_68 = "PLC4AF8508C6B340EA"						#Whitney Houston
YOUTUBE_CHANNEL_ID_69 = "PLJJKvAeu7rM302YZSoZqc3z3zIHJEsUrz"		#Motorhead
YOUTUBE_CHANNEL_ID_70 = "PLI9qt-hgfDJPBVTBkts63XsDrHAYVvaFy"		#Paolo Nutini
YOUTUBE_CHANNEL_ID_71 = "PL0O4mu7c5F7nrWVUciq_3d9PbQnGEyxUx"		#Duran Duran
YOUTUBE_CHANNEL_ID_72 = "PLoIl_zbeS3g_987gLIQeiXTOQ0JQP3zTQ"		#Eurythmics
YOUTUBE_CHANNEL_ID_73 = "PLnSnzH2IEsXqCVbrIt4tSG8gjxaHGc1p7"		#Human League
YOUTUBE_CHANNEL_ID_74 = "PLhkvvugdKb-fPGV2JOYQYSmOYMki5Rw-6"		#The Prodigy
YOUTUBE_CHANNEL_ID_75 = "PLMpM3Z0118S7an6E_3v8cAYBD_vCSClfB"		#Oasis
YOUTUBE_CHANNEL_ID_76 = "PLKak0ej7wSZPsqWRVCCHDyW0mBLNk9_dR"		#Genesis
YOUTUBE_CHANNEL_ID_77 = "PLMufE2NSPYOwPlJnRYtW-blFK4zr5W2K6"		#Phil Collins
YOUTUBE_CHANNEL_ID_78 = "PLb7YSwrGOyBRt2F1u0rln7M_tYNquuTnw"		#Billy Joel
YOUTUBE_CHANNEL_ID_79 = "PLgH-EhCJ58V0jguAS5EuejMYwO87QxC1I"		#Cascada
YOUTUBE_CHANNEL_ID_80 = "PL36PKo7DXhGlm0W67I8lpSq3j2Y32N6Q"			#Pulp
YOUTUBE_CHANNEL_ID_81 = "PLXu_cA-xfxWvLX12HK4BNSJ86tjhMpgNt"		#Kanye West
YOUTUBE_CHANNEL_ID_82 = "PLL8N99hsW_mtGwl1v7b_zQtH1FazWG6Np"		#Jason Derulo
YOUTUBE_CHANNEL_ID_83 = "PLAkqjw1_WMamxOH1YjwFoXHkwaINt26YK"		#Pet Shop Boys
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#
# YOUTUBE_CHANNEL_ID_xx = ""		#

# Compilations Added Initially
YOUTUBE_CHANNEL_ID_101 = "PL7KLwyJCC7QzpNciVGe-7K6ShC3MzL3vd"		#UK Pop
YOUTUBE_CHANNEL_ID_102 = "PL7KLwyJCC7QyXUZLdnHDbBIjBZZSOFRKk"		#UK Dance
YOUTUBE_CHANNEL_ID_103 = "PL7KLwyJCC7QznHKIubp_Sx0x3tuSX-IvB"		#Vintage
YOUTUBE_CHANNEL_ID_104 = "PLTZ5G8FX5UCNMMKGWa3r6Jwa7FmiE59Qs"		#Disney
YOUTUBE_CHANNEL_ID_105 = "PL55713C70BA91BD6E" 						#2016 Billboard
YOUTUBE_CHANNEL_ID_106 = "PLEB62A95CB8D0705C"						#80s Playlist
YOUTUBE_CHANNEL_ID_107 = "PLDB29F01702BF67F9"						#90s Playlist
YOUTUBE_CHANNEL_ID_108 = "PL941B1013DFDC1A5E"						#00s Playlist
YOUTUBE_CHANNEL_ID_109 = "PLz8JsiLUtVnA76pgXdnX_70eyko7t3dU_"		#MTV Hits 2016
YOUTUBE_CHANNEL_ID_110 = "PLWwAypAcFRgKAIIFqBr9oy-ZYZnixa_Fj"		#Rock 4000
YOUTUBE_CHANNEL_ID_111 = "PLD7SPvDoEddYd3OLS9T2ZT4eGc1iTwYG4"		#UK Charts 100
YOUTUBE_CHANNEL_ID_112 = "PLGhz17jGP_Qpkf3_xVkWNhA9JQxAr-Es5"		#Irish mix
YOUTUBE_CHANNEL_ID_113 = "PLlANO-LdYbCRjW8vmBIM0R9KlzInDQC1C"		#Hot videos
YOUTUBE_CHANNEL_ID_114 = "PLh7uAKJv9QJWk4ZuQcf9bxdMzNV-_5po8"		#Reggae
YOUTUBE_CHANNEL_ID_115 = "PLh7uAKJv9QJXmMbd-yA-sXgRlbBSgDY1r"		#Movie Soundtracks
YOUTUBE_CHANNEL_ID_116 = "PLGBuKfnErZlAkaUUy57-mR97f8SBgMNHh"		#70s Playlist
YOUTUBE_CHANNEL_ID_117 = "PLh7uAKJv9QJWCzz1wdoJo6jCLF6n7mtFW"		#Love Songs
YOUTUBE_CHANNEL_ID_118 = "PLCIUtWJVqcIi4-486sY9c25_mRYS15Oyj"		#Clubland
YOUTUBE_CHANNEL_ID_119 = "PLgtO5iWS0XgcoLSkuKo-VZClsDxsuIR7j"		#Kids Party
YOUTUBE_CHANNEL_ID_120 = "PLAihS1JLPtbSB8dtZKK0t77gl-kPOtGOf"		#Street Racer

# The Voice
YOUTUBE_CHANNEL_ID_201 = "PLPglX4LjfEan-B_pm6saR3w8Igdn2tWA1"		#Voice 2016
YOUTUBE_CHANNEL_ID_202 = "PLPglX4LjfEalnxfx1esw2HC6fEaHubBDp"		#Voice 2015
YOUTUBE_CHANNEL_ID_203 = "PLPglX4LjfEamOVyOf_H3bD8QW6pbdME9a"		#Voice 2014
YOUTUBE_CHANNEL_ID_204 = "PLPglX4LjfEakG1RKaw4MGLiZY_haPMHsg"		#Voice 2013
YOUTUBE_CHANNEL_ID_205 = "PLPglX4LjfEakl71qCd8TdbbFE9yn1cEaz"		#Voice 2012

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]2016 BILLBOARD HITS[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_105+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]70s GREATEST[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_116+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]80s GREATEST[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_106+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]90s GREATEST[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_107+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]00s GREATEST[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_108+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]DISNEY[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_104+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]KIDS PARTY[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_119+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]LOVE SONGS[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_117+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR blue][B]ROCK 4000[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_110+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR red][B]CLUBLAND[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_118+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR red][B]UK DANCE[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_102+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR red][B]UK POP[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_101+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow][B]MTV HITS 2016[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_109+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music2.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow][B]STREET RACER[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_120+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow][B]VINTAGE[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_103+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music1.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR green][B]UK CHARTS 100[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_111+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music4.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR green][B]HOT VIDEOS[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_113+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music7.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR green][B]IRISH PUB MIX[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_112+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music6.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR green][B]MOVIE SOUNDTRACKS[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_115+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music9.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR green][B]REGGAE & DANCEHALL[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_114+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music8.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR orange][B]THE VOICE 2016[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_201+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music5.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR orange][B]THE VOICE 2015[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_202+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music5.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR orange][B]THE VOICE 2014[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_203+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music5.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR orange][B]THE VOICE 2013[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_204+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music5.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR orange][B]THE VOICE 2012[/B][/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_205+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music5.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ACDC",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ADELE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AEROSMITH",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ARIANA GRANDE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="AVICII",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BEYONCE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BIG COUNTRY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BILLY JOEL",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_78+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BLINK 182",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BLUR",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BON JOVI",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BRITNEY SPEARS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BRYAN ADAMS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BUDDY HOLLY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="CASCADA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_79+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="CLIFF RICHARD",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="COLDPLAY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="CREED",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="DAVID BOWIE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="DEMI LOVATO",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="DRAKE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="DURAN DURAN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_71+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ELO",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ELTON JOHN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ELVIS PRESLEY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="EMINEM",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="EURYTHMICS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_72+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="EVANESCENCE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="FALL OUT BOY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="FOO FIGHTERS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GENESIS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_76+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GREEN DAY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="GUNS N ROSES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="HUMAN LEAGUE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_73+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="JASON DERULO",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_82+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="JOHN LEGEND",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="JOHNNY CASH",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="JOURNEY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="KANYE WEST",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_81+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="KATY PERRY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="KELLY CLARKSON",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="LADY GAGA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="LINKIN PARK",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MADONNA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MAROON 5",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MARY J BLIGE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MEATLOAF",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MEGHAN TRAINOR",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MICHAEL BALL",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_67+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MICHAEL BUBLE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_66+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MOTORHEAD",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_69+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MY CHEMICAL ROMANCE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="NIRVANA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="OASIS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_75+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ONE DIRECTION",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PAUL WELLER",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PAULO NUTINI",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_70+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PET SHOP BOYS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_83+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PHIL COLLINS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_77+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PRINCE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PULP",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_80+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="QUEEN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RED HOT CHILLI PEPPERS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RICKY MARTIN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RITA ORA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_65+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ROD STEWART",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ROLLING STONES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SAM SMITH",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SHAKIRA",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SHANIA TWAIN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="SIMPLY RED",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="STEREOPHONICS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/music.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="TAKE THAT",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="TAYLOR SWIFT",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="THE BEATLES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="THE PRODIGY",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_74+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="THE SCRIPT",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="TRACY CHAPMAN",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="U2",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="UB40",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ULTRAVOX",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WESTLIFE",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicb.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WHITNEY HOUSTON",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_68+"/",
        thumbnail="special://home/addons/plugin.video.merlinmusic/resources/musicg.png",
        folder=True )

run()