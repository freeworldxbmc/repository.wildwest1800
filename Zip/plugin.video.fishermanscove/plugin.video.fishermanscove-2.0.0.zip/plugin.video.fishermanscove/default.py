import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,datetime,shutil,urlresolver,random,yt,plugintools
from resources.libs.common_addon import Addon

addon_id        = 'plugin.video.fishermanscove'
addon           = Addon(addon_id, sys.argv)
fanart          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
baseurl         = 'http://kodimadeeasy.uk/thefishcove/index.xml'

YOUTUBE_CHANNEL_ID_1 = "PL152bjytsMC5IAot7hLowOewo2Dioib5k"

def GetList():
        link=open_url(baseurl)
        match= re.compile('<link>(.+?)</link><thumbnail>(.+?)</thumbnail><title>(.+?)</title>').findall(link)
        for url,iconimage,name in match:
                if not 'http' in iconimage:iconimage=icon
                addDir(name,url,1,iconimage,fanart)

def GetContent(url,iconimage):

        if '/abc.txt' in url:
             print "dobba -> ABC.txt"
             main_list()
             return()

			   
			   
			   
        link=open_url(url)
        match= re.compile('<link>(.+?)</link><thumbnail>(.+?)</thumbnail><title>(.+?)</title>').findall(link)
        for url,iconimage,name in match:
		
                print " detected url: " + url
		
                if not 'http' in iconimage:iconimage=icon
				
                if '/kodimadeeasy.uk/thefishcove/' in url:
					 addDir(name,url,1,iconimage,fanart)
				
                
                      
                else:addLink(name,url,2,iconimage,fanart)

def PLAYLINK(url,iconimage):
        stream_url = urlresolver.HostedMediaFile(url).resolve()
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                                     
def open_url(url):
        url=url.replace(' ','%20')
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param
               
def addDir(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def add_item( action="" , title="" , plot="" , url="" , thumbnail="" , fanart="" , show="" , episode="" , extra="", page="", info_labels = None, isPlayable = False , folder=True ):
    #_log("add_item action=["+action+"] title=["+title+"] url=["+url+"] thumbnail=["+thumbnail+"] fanart=["+fanart+"] show=["+show+"] episode=["+episode+"] extra=["+extra+"] page=["+page+"] isPlayable=["+str(isPlayable)+"] folder=["+str(folder)+"]")

    listitem = xbmcgui.ListItem( title, iconImage="DefaultVideo.png", thumbnailImage=thumbnail )
    if info_labels is None:
        info_labels = { "Title" : title, "FileName" : title, "Plot" : plot }
    listitem.setInfo( "video", info_labels )

    if fanart!="":
        listitem.setProperty('fanart_image',fanart)
        xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)
    
    if url.startswith("plugin://"):
        itemurl = url
        listitem.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    elif isPlayable:
        listitem.setProperty("Video", "true")
        listitem.setProperty('IsPlayable', 'true')
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % ( sys.argv[ 0 ] , action , urllib.quote_plus( title ) , urllib.quote_plus(url) , urllib.quote_plus( thumbnail ) , urllib.quote_plus( plot ) , urllib.quote_plus( extra ) , urllib.quote_plus( page ))
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)
    else:
        itemurl = '%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % ( sys.argv[ 0 ] , action , urllib.quote_plus( title ) , urllib.quote_plus(url) , urllib.quote_plus( thumbnail ) , urllib.quote_plus( plot ) , urllib.quote_plus( extra ) , urllib.quote_plus( page ))
        xbmcplugin.addDirectoryItem( handle=int(sys.argv[1]), url=itemurl, listitem=listitem, isFolder=folder)		
		
# Main menu
def main_list():

		######################################################################################################################################################
    add_item( 
        #action="", 
        title="---[COLOR red]CHANNELS[/COLOR]---",
        url="plugin://plugin.video.youtube/playlist/PLNIzo6AOIKUgzWrawbSX7YjzVo8dyZDcF/",
        thumbnail="https://i.ytimg.com/vi/MXDtnw0Vt2c/maxresdefault.jpg",
        folder=True )

    add_item( 
        #action="", 
        title="Korda TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UContEaeqonv1e131k03FyMA/",
        thumbnail="http://www.gofishing.co.uk/upload/36361/images/Korda_Team_England.jpg",
        folder=True )		
		
    add_item( 
        #action="", 
        title="Nash TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCaULe1cc4jCQ6ZzUrDY81Sg/",
        thumbnail="http://2.bp.blogspot.com/-2CnCluhx1O8/UOc9_M0oVrI/AAAAAAAAAlM/DrWdg6t5YDI/s1600/nash-tackle-logo-13.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Fox International TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UC7l_C-SB-TyxXR3qmgBnWPw/",
        thumbnail="http://accringtoncoarseandcarp.co.uk/wp-content/uploads/2015/12/C1A9C523-7119-471B-A0E2-A981203C463C.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Avid Carp TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCHi0_fzKiqxVnZMlscX1YJg/",
        thumbnail="http://www.manorfarmfishing.co.uk/media/catalog/category/avid_carp.png",
        folder=True )
		
    add_item( 
        #action="", 
        title="Carl and Alex from Nash -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCDH-BQ_G44oIt7f8RdQXNPg/",
        thumbnail="http://www.tourismchilliwack.com/files/Image/Fish%20Chilliwack.com/Salmon,%20Alex.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Gardner Tackle / ATT -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCU-RrAVhFTliBG_d3ZJ-crQ/",
        thumbnail="http://www.barbel.co.uk/site/gardner.gif",
        folder=True )
		
    add_item( 
        #action="", 
        title="Mainline Baits -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCJbeY_7iSbTiWcNUTT2kmTw/",
        thumbnail="http://www.ukmatchangler.com/carp/images/bait/mainline/hybrid/1.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="River Monsters -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UComwL29zYKujb1JhkB0EcGA/",
        thumbnail="http://i.cdn.travel.cnn.com/sites/default/files/styles/inline_image_624x416/public/2013/01/10/teles-piris-jau-catfish.jpg?itok=UbrfRWKo",
        folder=True )
		
    add_item( 
        #action="", 
        title="Anglers Mail TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCbKVBxKBBOMsjAhaMRopQfA/",
        thumbnail="http://www.korum.co.uk/img/img_articles/thumbs/anglers-mail-logo.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Fishing TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCuqKu1s9sjGpMupu2Mazu9Q/",
        thumbnail="https://i.ytimg.com/vi/XZeh_Bk--x0/hqdefault.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Carpheadbangers TV -[COLOR yellow] FULL CHANNEL[/COLOR] ",
        url="plugin://plugin.video.youtube/channel/UCFhnnIKuj0qP4NtVXmoZ5gw/",
        thumbnail="https://pbs.twimg.com/profile_images/572520413454077952/ORT9S0GG.jpeg",
        folder=True )
		#######################################################################################################################################################
    add_item( 
        #action="", 
        title="---[COLOR red]PLAYLISTS[/COLOR]---",
        url="plugin://plugin.video.youtube/playlist/PLNIzo6AOIKUgzWrawbSX7YjzVo8dyZDcF/",
        thumbnail="https://i.ytimg.com/vi/MXDtnw0Vt2c/maxresdefault.jpg",
        folder=True )

    add_item( 
        #action="", 
        title="John Wilson - Go Fishing",
        url="plugin://plugin.video.youtube/playlist/PLNIzo6AOIKUgzWrawbSX7YjzVo8dyZDcF/",
        thumbnail="http://www.gofishing.co.uk/upload/28456/images/wilson%20with%20big%20barbel.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Bob Nudd",
        url="plugin://plugin.video.youtube/playlist/PLh7uAKJv9QJXsH0dqs8GfmSzFRTBX-jk_/",
        thumbnail="http://www.anglingdirect.co.uk/wp/wp-content/uploads/2015/05/Float-Fishing-For-Tench-1-copy.jpg",
        folder=True )

    add_item( 
        #action="", 
        title="The Greater Rod Race",
        url="plugin://plugin.video.youtube/playlist/PLNIzo6AOIKUgNE9W0dgZPqO6DK-36f4gy/",
        thumbnail="https://i.ytimg.com/vi/NR941fy6IYM/maxresdefault.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Record Breakers - Matt Hayes",
        url="plugin://plugin.video.youtube/playlist/PLKO1C_NUo_bYX37TMCcDYWeQC6t9REsWk/",
        thumbnail="https://i.ytimg.com/vi/NR941fy6IYM/maxresdefault.jpg",
        folder=True )		
		
    add_item( 
        #action="", 
        title="Lake Escapes - Matt Hayes",
        url="plugin://plugin.video.youtube/playlist/PLcVvDtWcMP9n5pbMGCFO5gCU88vUUOD3H/",
        thumbnail="https://i.ytimg.com/vi/NR941fy6IYM/maxresdefault.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Matt Hayes - Total Fishing - Season 1",
        url="plugin://plugin.video.youtube/playlist/PLcVvDtWcMP9k5rVV3jz_CvrUnSIabizrL/",
        thumbnail="https://i.ytimg.com/vi/NR941fy6IYM/maxresdefault.jpg",
        folder=True )

    add_item( 
        #action="", 
        title="Matt Hayes - Total Fishing - Season ",
        url="plugin://plugin.video.youtube/playlist/PLcVvDtWcMP9mWSpFlT-zieyaxjqF4G0Qs/",
        thumbnail="https://i.ytimg.com/vi/NR941fy6IYM/maxresdefault.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Fishing Gurus Season 1 ",
        url="plugin://plugin.video.youtube/playlist/PLXjy0EZO7XwBFujBUPLE-CYcH3jUGr_aE/",
        thumbnail="http://www.korda.co.uk/images/tv_listing/thumb_fishing_gurus.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Fishing Gurus Season 3 ",
        url="plugin://plugin.video.youtube/playlist/PLSf24Tc2uid11kKqGC1ADxHhG6JWwCaWm/",
        thumbnail="http://www.korda.co.uk/images/tv_listing/thumb_fishing_gurus.jpg",
        folder=True )

    add_item( 
        #action="", 
        title="Dave Lane Carp Fishing Video Diary",
        url="plugin://plugin.video.youtube/playlist/PLoEWpnwtJrCN8nf8iYiX8uAgXPB_xRR1S/",
        thumbnail="http://blog.fishtec.co.uk/wp-content/uploads/2012/08/DaveLanef.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Popular Videos - Carp fishing & Lake (200+ VIDEOS)",
        url="plugin://plugin.video.youtube/playlist/PLoinB2KmhVaF8LNzeLVraSFNV862qiYi6/",
        thumbnail="http://www.essexcarpsyndicates.co.uk/images/essex-carp/carp-fishing-rules.jpg",
        folder=True )
		
    add_item( 
        #action="", 
        title="Barbel Fishing On The Swale",
        url="plugin://plugin.video.youtube/playlist/PLjaM2hYZHGlBci7hnp7wYZgRj3XzqU8D1/",
        thumbnail="http://www.countrysportsyorkshire.co.uk/wp-content/uploads/2013/08/river-swale-barbel.jpg",
        folder=True )

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
 
print "Site: "+str(site); print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
 
if mode==None or url==None or len(url)<1: GetList()
elif mode==1:GetContent(url,iconimage)
elif mode==2:PLAYLINK(url,iconimage)
elif mode==3:add_item( action="" , title="" , plot="" , url="" , thumbnail="" , fanart="" , show="" , episode="" , extra="", page="", info_labels = None, isPlayable = False , folder=True )

xbmcplugin.endOfDirectory(int(sys.argv[1]))
