config = {
    'urls': {
        'calm_website': 'https://calmradio.com',
        'calm_api': 'https://calmradio.com/webplayer/streaminfo.xml',
        'vtuner_search': 'http://vtuner.com/setupapp/guide/asp/BrowseStations/SearchForm.asp?sSearchInput={0}',
        'vtuner_mms': 'http://www.vtuner.com/vtunerweb/mms/'
    }
}