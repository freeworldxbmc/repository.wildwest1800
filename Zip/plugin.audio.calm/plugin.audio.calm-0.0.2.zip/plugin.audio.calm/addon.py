from xbmcswift2 import Plugin, xbmc, xbmcgui
from api import API


plugin = Plugin()
api = API(plugin)


@plugin.route('/')
def index():
    return plugin.finish([{
        'label': item['label'],
        'icon': 'special://home/addons/plugin.audio.calm/resources/media/fanarts/{0}.jpg'.format(item['id']),
        'path': plugin.url_for('show_channels', category_id=item['id'], subcategory_id=item['id']),
        'properties': {
            'fanart_image': 'special://home/addons/plugin.audio.calm/resources/media/fanarts/{0}.jpg'.format(item['id'])
        }
    } for item in api.get_subcategories() if item['id'].startswith('0')])


@plugin.route('/category/<category_id>/subcategory/<subcategory_id>')
def show_channels(category_id, subcategory_id):
    return plugin.finish([{
        'label': item['label'],
        'icon': item['visual'],
        'path': plugin.url_for('play_channel', title=item['label'], icon=item['visual']),
        # 'is_playable': False,
        'properties': {
            'fanart_image': 'special://home/addons/plugin.audio.calm/resources/media/fanarts/{0}.jpg'
                         .format(subcategory_id),
            'artist_description': item['description']
        }
    } for item in api.get_channels(subcategory_id)])


@plugin.route('/play')
def play_channel():
    title = plugin.request.args['title'][0]
    icon = plugin.request.args['icon'][0]
    path = api.get_stream(title)
    if path:
        listitem = xbmcgui.ListItem(title, path=path, iconImage=icon, thumbnailImage=icon)
        listitem.setArt({ 'poster': icon, 'banner' : icon, 'thumb': icon, 'fanart': icon })
        listitem.setProperty('IsPlayable', 'true')
        listitem.setInfo('music',  {
            'title': title,
            'artist': 'Calm Radio'
        })
        xbmc.Player().play(path, listitem)
    else:
        plugin.notify('Streamin not found')


if __name__ == '__main__':
    plugin.run()
