from urlparse import urljoin
from bs4 import BeautifulSoup
from cache import Cache
from config import config
import re
import requests
import xml.etree.ElementTree as ET


class API(object):
    def __init__(self, plugin):
        self.plugin = plugin

    @staticmethod
    @Cache
    def get_calm_data():
        r = requests.get(config['urls']['calm_api'])
        if r.status_code == 200:
            return ET.fromstring(r.content)

    def get_categories(self):
        return [
            {
                'id': '0',
                'label': 'Music',
                'icon': 'special://home/addons/plugin.audio.calm/resources/media/fanarts/0.jpg',
                'description': 'Acoustic, Classical, World, Relaxation and Jazz music channels'
            },
            {
                'id': '1',
                'label': 'Atmospheres',
                'icon': 'special://home/addons/plugin.audio.calm/resources/media/fanarts/1.jpg',
                'description': 'Music specially designed for sleep, concentration and for ringing-in-the-ear sufferers'
            }
        ]

    def get_subcategories(self):
        return [
            {
                'id': '0.1',
                'label': 'Acoustic',
                'icon': ''
            },
            {
                'id': '0.2',
                'label': 'Relaxation',
                'icon': ''
            },
            {
                'id': '0.3',
                'label': 'Classical',
                'icon': ''
            },
            {
                'id': '0.4',
                'label': 'Composers',
                'icon': ''
            },
            {
                'id': '0.5',
                'label': 'World',
                'icon': ''
            },
            {
                'id': '0.6',
                'label': 'Jazz',
                'icon': ''
            },
            {
                'id': '0.7',
                'label': 'Latin',
                'icon': ''
            },
            {
                'id': '0.8',
                'label': 'Country',
                'icon': ''
            },
            {
                'id': '0.9',
                'label': 'Pop Rock',
                'icon': ''
            },
            {
                'id': '1.0',
                'label': 'Water',
                'icon': ''
            },
            {
                'id': '1.1',
                'label': 'Creatures',
                'icon': ''
            },
            {
                'id': '1.2',
                'label': 'White Noise',
                'icon': ''
            },
            {
                'id': '1.3',
                'label': 'Nature',
                'icon': ''
            },
            {
                'id': '1.4',
                'label': 'Space',
                'icon': ''
            }
        ]

    def get_channels(self, subcategory_id):
        items = []
        root = API.get_calm_data()
        for item in root.findall('item'):
            if item.find('category').text == subcategory_id and item.find('active').text == 'true':
                items.append(
                    {
                        'label': item.find('title').text,
                        'visual': urljoin(config['urls']['calm_website'], item.find('visual').text),
                        'description': item.find('description').text,
                        # 'is_playable': True
                    }
                )
        return items

    def get_stream(self, channel_title):
        r = requests.get(config['urls']['vtuner_search'].format('Calm%20Radio%20-%20{0}'.format(channel_title.replace('%20and%20', '%20&%20'))))
        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html.parser')
            link = soup.select('a[href*="dynampls.asp"]')
            if link:
                link = link[0]
                station_id = re.search('id=(\d+)$', link.get('href')).group(1)
                r2 = requests.get(urljoin(config['urls']['vtuner_mms'], 'm3u{0}.m3u'.format(station_id)))
                if r2.status_code == 200:
                    return r2.content.strip()
        return ''
