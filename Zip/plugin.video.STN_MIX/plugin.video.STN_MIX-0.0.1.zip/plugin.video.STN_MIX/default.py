import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin


def CATEGORIES():
   r = requests.get('https://c40fb24424fa6beeb2a20d1282258500a69c6a92.googledrive.com/host/0B88fGGARV1mmUjNqM2NpbjdKS2c/header.txt')
   match = re.compile('announcement = "(.+?)"').findall(r.content)
   for announcement in match:
       addDir3('[COLOR green]%s[/COLOR]'%announcement,'','','','','')
   addDir3('[B]Tv Shows[/B]','http://tv.dl-pars.in/',400,'https://ia801501.us.archive.org/8/items/HindiShows/tv%20shows.png','https://i.ytimg.com/vi/RdX6RezCHE4/maxresdefault.jpg','')
   addDir3('[B]Hindi Shows[/B]','http://',1000,'https://ia801501.us.archive.org/8/items/HindiShows/Hindi%20shows.png','https://i.ytimg.com/vi/RdX6RezCHE4/maxresdefault.jpg','')
   addDir3('[B]Movies[/B]','http://',300,'https://ia801501.us.archive.org/8/items/HindiShows/movies.png','https://i.ytimg.com/vi/RdX6RezCHE4/maxresdefault.jpg','')
   addDir3('[B]IPTV[/B]','http://',1999,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','https://i.ytimg.com/vi/RdX6RezCHE4/maxresdefault.jpg','')
   addDir3('[B]Live Events[/B]','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/LIVE%20SPORTS.txt',3000,'https://ia601509.us.archive.org/29/items/LIVEEVENTS_201606/LIVE%20EVENTS.png','https://i.ytimg.com/vi/RdX6RezCHE4/maxresdefault.jpg','')
############################################################## TV Shows ########################################################################################	    

def tvShows():
   r = requests.get('http://tv.dl-pars.in/')
   match = re.compile('<tr><td><a href="(.+?)">(.+?)/</a></td><td>-</td><td>.+?</td></tr>').findall(r.content)
   for url,name in match:
       addDir3(name,url,500,'','','')

def season(url, iconimage):
   r = requests.get('http://tv.dl-pars.in/%s'%url)
   match = re.compile('<tr><td><a href="(.+?)/">(.+?)/</a></td><td>-</td><td>.+?</td></tr>').findall(r.content)
   for url2,name in match:
       if name != 'Parent directory':
         addDir3(name,'http://tv.dl-pars.in/%s%s'%(url,url2),600,'','','')


def playSeason(url, iconimage):
   r = requests.get(url)
   match = re.compile('<tr><td><a href="(.+?)">(.+?)</a></td><td>.+?</td><td>.+?</td></tr>').findall(r.content)
   for url3,name in match:
     if name != 'Parent directory/':
      addLink(name,'%s/%s'%(url,url3),'','','')
############################################################## Hollywood Movies ########################################################################################	 

def main2():   
   addDir3('Movies [COLOR green]-[/COLOR] [B][Browse by year][/B]','http://dl5.nightsdl.com/Masih/Film/',11,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   #addDir3('Movies [COLOR green][2][/COLOR]- (dl.farsimovie.net/Movie/5/)','http://dl.farsimovie.net/Movie/5/',8,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   #addDir3('Movies [COLOR green][3][/COLOR]- (sv.dl-pars.in/Ali/)','http://sv.dl-pars.in/Ali/',7,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   #addDir3('Movies [COLOR green][4][/COLOR]- (sv.dl-pars.in/ghadimi/)','http://sv.dl-pars.in/ghadimi/',5,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   #addDir3('Movies [COLOR green][5][/COLOR]- (sv.dl-pars.in/250 Top Movies/)','http://sv.dl-pars.in/250%20Top%20Movies/',6,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   #addDir3('Movies [COLOR green][6][/COLOR]- (cloud.orangebananaspy.com/Movies/)','http://cloud.orangebananaspy.com/Movies/',9,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   addDir3('[B][COLOR gold]-->My Collection:[/COLOR][/B]','','','http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg','')
   
   r = requests.get('https://www.googledrive.com/host/0B0-Dtcj4ShdydWdRT0R0SU5CQlk/catagories.txt')
   match = re.compile('name="(.+?)" url="(.+?)" image="(.+?)" fanart="(.+?)"').findall(r.content)
   for name,url,image,fanart  in match:
     addDir3(name,url,3,image,fanart,'')
	 
def ftp():
   r = requests.get('http://dl.farsimovie.net/Movie/5/')
   match = re.compile('<a href="(.+?)">(.+?)</a>').findall(r.content)
   for url,name in match:
     addLink(name,'http://dl.farsimovie.net/Movie/5/%s'%url,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg')

def dl():
   r = requests.get('http://dl.farsimovie.net/Movie/5/')
   match = re.compile('<a href="(.+?)">(.+?).Farsi.+?</a>').findall(r.content)
   for url,name in match:
     addLink(name,'http://dl.farsimovie.net/Movie/5/%s'%url,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg')


def svDl():
   r = requests.get('http://sv.dl-pars.in/Ali/')
   match = re.compile('<td><a href="(.+?)">(.+?)(.+?).mkv</a></td>').findall(r.content)
   for url,name,part2 in match:
     addLink(name+part2,'http://sv.dl-pars.in/Ali/%s'%url,'http://az616578.vo.msecnd.net/files/2016/03/05/635928048973059291-1373758031_Movies.jpg','','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg')


def year():
   r = requests.get('http://dl5.nightsdl.com/Masih/Film/')
   match = re.compile('<tr><td><a href="(.+?)/">.+?/</a></td><td>-</td><td>.+?</td></tr>').findall(r.content)
   for uname in match:
     if uname != '..':
      addDir3(uname,'http://dl5.nightsdl.com/Masih/Film/%s'%uname,12,'','','')
     
def play(url): 
   r = requests.get(url)
   match = re.compile('<tr><td><a href="(.+?)-(.+?)">.+?</a></td><td>.+?</td><td>.+?</td></tr>').findall(r.content)
   for uname2,part2 in match:
        if uname2 != '../">Parent directory/</a></td><td>':
	     addLink(uname2,url+'/%s'%uname2+'-'+part2,'','','')

def MoviessH(url):
   r = requests.get(url)
   match = re.compile('name= "(.+?)" url="(.+?)" image="(.+?)"').findall(r.content)
   for hname,hurl,himage  in match:
     addLink(hname,hurl,himage,'','http://www.androidtvteesside.info/kodi/Repo/xbmc%20backgrounds/b0HHX1a.jpg')

############################################################## Hindi Shows ########################################################################################	 

def hindiShows():
  addDir3('Sony-TV','http://apne.tv/Channels/Sony-TV',1001,'http://4.bp.blogspot.com/-cEXXudQblB8/TcK-ZdRxdQI/AAAAAAAAFis/7908Rym35Gg/s1600/Sony%20TV%20logo.png','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  addDir3('Star-Plus','http://apne.tv/Channels/Star-Plus',1001,'http://vignette3.wikia.nocookie.net/logopedia/images/9/9b/Star_Plus_USA.png/revision/latest?cb=20110930095924','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  #addDir3('Colors','http://apne.tv/Channels/Colors',3,'http://vignette2.wikia.nocookie.net/logopedia/images/3/33/Colors_TV.png/revision/latest?cb=20111013225802','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  addDir3('Sab-Tv','http://apne.tv/Channels/Sab-TV',1001,'http://www.venturabroadcasting.com/wp-content/uploads/2015/07/SAB_TV-logo-255x300.png','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  #addDir3('MTV-Hindi','http://apne.tv/Channels/MTV-Hindi',3,'http://www.indiantelevision.com/sites/drupal7.indiantelevision.co.in/files/images/tv-images/2015/06/08/Untitled-1_0.jpg','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  addDir3('Life-OK','http://apne.tv/Channels/Life-OK',1001,'http://www.ebuzzintown.com/wp-content/uploads/2012/11/Life-OK-TV-channel.jpg','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  #addDir3('Zee-Tv','http://apne.tv/Channels/Zee-TV',3,'http://www.onevveb.com/balajient/wp-content/uploads/2014/09/ZEE_TV_HD_Logo.jpg','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
  #addDir3('AndTv','http://apne.tv/Channels/AndTV',3,'http://tvimages.burrp.com/images/channels1/Entertainment/and%20tv.png','http://sv102.piclect.com/2374fb3d0/m/14/12/19/india.jpg','')
   
def channelShow(url, iconimage):
     addDir('[COLOR red]The Shows keep looping[/COLOR]','','','')
     r2 = requests.get(url)
     match2 = re.compile('<li><a href="(.+?)"><b>(.+?)</b> </a> </li>').findall(r2.content)
     for url2, date in match2:
	    addDir3(date,url2,1002,iconimage,'','') 


def playSHOW(name, url):
     r = requests.get('http://apne.tv/Hindi-Serial/%s'%name)
     match = re.compile('<img src="(.+?)" class="attachment-medium-feature wp-post-image" height="165" width="250" style="width:250px;height:165px;"><span class="overlay_icon fa fa-quote-left">').findall(r.content)
     for image in match:
      r2 = requests.get('http://apne.tv/Hindi-Serial/episodes/%s'%name)
      match2 = re.compile('<a href="(.+?)" style="margin-right:0px;" class="date_episodes"><i class="icon-calendar"></i> <span>(.+?)</span></a>').findall(r2.content)
      for url3, date in match2:
        addDir3(date,url3,1003,image,'','')		

def playSHOW2(name, url, iconimage):
     r2 = requests.get(url)
     match2 = re.compile("<a href='(.+?).mp4' title='(.+?)' target='_blank'>.+?</a>").findall(r2.content)
     for play, title in match2:
	    addLink(title,'%s.mp4'%play,iconimage,'','')
#########################################################################  IPTV ##################################################################
def IptvCatagories():
    addDir3('Source - 1','http://',2000,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','Source= Sasta Tv')
    addDir3('Source - 2','http://',4000,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','Source= PakIndiaTv')
def SastaTvgroup(url):     
	 addDir3('Drama','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Drama.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Infotainment','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Infotainment.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Kids','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Kids.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Movies','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Movies.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Music','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Music.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('News','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/News.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Regional','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Regional.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Sky','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Sky%20.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Sports','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/Sports.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')
	 addDir3('Devotional','https://ea592841612c1b675969e772170e5f06fa3a3ca8.googledrive.com/host/0B88fGGARV1mmZmhDZVZ5c3NQOE0/Sasta%20tv/devotional.txt',2001,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','http://kodicommunity.com/wp-content/uploads/2016/01/xr1ygTD.png','')


def SastaTvUrl(url):
     r = requests.get(url)
     match = re.compile('                                <a class="dropdown-item" href="(.+?)">(.+?)</a>').findall(r.content)
     for url2,name in match:
        r2 = requests.get('https://sastatv.com/demo/%s'%url2)
        match2 = re.compile('file: "(.+?)"').findall(r2.content)
        for url3 in match2:
		  addLink(name,url3,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','','http://i.imgur.com/P1qynOe.jpg')
	    
def pakTv():
 r2 = requests.get('https://c9423c5b84e03d1d2ea152a2857b83a2d2d8a565.googledrive.com/host/0B88fGGARV1mmNmxZQXE4STNFZjA/Channels.txt')
 match2 = re.compile('{"categoryName": ".+?", "channelLink": "(.+?)", "mainCatName": ".+?", "categoryLogo": ".+?", "channelName": "(.+?)", "catPriority": ".+?"}').findall(r2.content)
 for url, name in match2:
  addLink(name,url,'https://ia801501.us.archive.org/8/items/HindiShows/IPTV.png','','http://i.imgur.com/P1qynOe.jpg')
   
#########################################################################  Live Sports events ###################################################################    			

def sportsEvents():
     r = requests.get('https://9350e85f435e956132a807c99cdca4d5bd6a2a98.googledrive.com/host/0B88fGGARV1mmWGc3eGZYcnR4TFE/main.txt')
     match = re.compile('name = "(.+?)" url = "(.+?)" image = "(.+?)"').findall(r.content)
     for name, url, image in match:
	    addDir3(name,url,3001,image,'','')

def getStreams(url):
     r = requests.get(url)
     match = re.compile('{"categoryName": ".+?", "channelLink": "(.+?)", "mainCatName": ".+?", "categoryLogo": ".+?", "channelName": "(.+?)", "catPriority": ".+?"}').findall(r.content)
     for url2, name2 in match:
	    addLink(name2,url2,'','','')

def addLink(name,url,image,urlType,fanart):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('IsPlayable','true')
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       
#################################################################################################################

#                               NEED BELOW CHANGED

  
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
     
def addDir2(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
 


              
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        OPEN_URL(url)
elif mode==3:
        MoviessH(url)
elif mode==11:
        year()
elif mode==12:
        play(url)
elif mode==300:
        main2()
elif mode==400:
        tvShows()
elif mode==500:
		season(url, iconimage)
elif mode==600:
		playSeason(url, iconimage)
elif mode==1000:
        hindiShows()
elif mode==1001:
        channelShow(url, iconimage)
elif mode==1002:
         playSHOW(name, url)
elif mode==1003:
         playSHOW2(name, url, iconimage)
elif mode==1999:
         IptvCatagories()
elif mode==2000:
         SastaTvgroup(url)
elif mode==2001:
         SastaTvUrl(url)
elif mode==3000:
         sportsEvents()
elif mode==3001:
         getStreams(url)
elif mode==4000:
         pakTv()
        
        


xbmcplugin.endOfDirectory(int(sys.argv[1]))
